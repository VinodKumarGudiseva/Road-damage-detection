import streamlit as st
import sqlite3
import pandas as pd
from pathlib import Path
from streamlit_autorefresh import st_autorefresh
st_autorefresh(
    interval=5000,
    key="refresh"
)
st.set_page_config(
    page_title="Road Damage Dashboard",
    layout="wide"
)

st.title("Road Damage Detection Dashboard")

ROOT = Path(__file__).resolve().parent.parent

db_path = ROOT / "database_files" / "pothole.db"

try:
    conn = sqlite3.connect(str(db_path))

    df = pd.read_sql_query(
    "SELECT * FROM detections",
    conn
    )
    if df.empty:
        st.warning("No detections found in database.")
        st.stop()
    df["damage_type"] = df["damage_type"].replace(
        {"carck": "crack"}
    )

    conn.close()

    st.success("Database Connected")

    search_term = st.text_input(
    "Search Damage Type"
    )

    if search_term:
        df = df[
            df["damage_type"].str.contains(
                search_term,
                case=False,
                na=False
            )
        ]
    damage_filter = st.selectbox(
    "Filter by Damage Type",
    ["All", "pothole", "crack", "manhole"]
    )
    date_filter = st.date_input(
    "Filter by Date",
    value=None
    )

    if date_filter:
        df["date"] = pd.to_datetime(
            df["timestamp"]
        ).dt.date

        df = df[
            df["date"] == date_filter
        ]
    if damage_filter != "All":
        df = df[
            df["damage_type"] ==
            damage_filter
        ]

    if df.empty:
        st.warning(
            "No records found for the selected filters."
        )
        st.stop()
    total = len(df)
    potholes = len(
        df[df["damage_type"] == "pothole"]
    )

    cracks = len(
        df[df["damage_type"] == "crack"]
    )

    manholes = len(
        df[df["damage_type"] == "manhole"]
    )
    avg_confidence = round(
        df["confidence"].mean(),
        2
    )

    high_severity = len(
        df[df["severity"] == "High"]
    )
    metrics_file = (
    ROOT / "models" / "results.csv"
    )

    if metrics_file.exists():

        metrics_df = pd.read_csv(
        metrics_file
        )

        latest_metrics = metrics_df.iloc[-1]

        precision = round(
        latest_metrics["metrics/precision(B)"],
        4
        )

        recall = round(
        latest_metrics["metrics/recall(B)"],
        4
        )

        map50 = round(
        latest_metrics["metrics/mAP50(B)"],
        4
        )

        map5095 = round(
        latest_metrics["metrics/mAP50-95(B)"],
        4
        )
        accuracy = round(
        (precision + recall) / 2,
        4
        )
        if precision + recall > 0:
            f1 = round(
            2 * precision * recall /
            (precision + recall),
            4
            )
        else:
            f1 = 0

    else:

        precision = 0
        recall = 0
        map50 = 0
        map5095 = 0
        f1 = 0

        st.warning(
        "Model metrics file not found."
        )
    
    col1, col2, col3, col4, col5, col6 = st.columns(6)

    col1.metric(
        "Total Detections",
        total
    )

    col2.metric(
        "Potholes",
        potholes
    )

    col3.metric(
        "Cracks",
        cracks
    )

    col4.metric(
        "Manholes",
        manholes
    )
    col5.metric(
        "Average Confidence",
        avg_confidence
    )

    col6.metric(
        "High Severity Cases",
        high_severity
    )
    st.markdown("---")
    st.subheader(
    "Model Performance Metrics"
    )

    col7, col8, col9 = st.columns(3)

    col7.metric(
    "Precision",
    f"{precision:.4f}"
    )

    col8.metric(
    "Recall",
    f"{recall:.4f}"
    )

    col9.metric(
    "F1 Score",
    f"{f1:.4f}"
    )

    col10, col11, col12 = st.columns(3)

    col10.metric(
    "Accuracy",
    f"{accuracy:.4f}"
    )

    col11.metric(
    "mAP@50",
    f"{map50:.4f}"
    )

    col12.metric(
    "mAP@50-95",
    f"{map5095:.4f}"
    )
    
    st.subheader("Damage Distribution")

    chart_data = {
        "Damage Type": [
            "Pothole",
            "Crack",
            "Manhole"
        ],
        "Count": [
            potholes,
            cracks,
            manholes
        ]
    }

    chart_df = pd.DataFrame(chart_data)

    st.bar_chart(
    chart_df.set_index(
        "Damage Type"
    )
    )
    st.subheader(
    "Confidence Trend"
    )

    st.line_chart(
        df["confidence"]
    )
    st.subheader(
        "Severity Distribution"
    )

    severity_counts = (
        df["severity"]
        .value_counts()
    )

    st.bar_chart(
        severity_counts
    )

    st.subheader("Recent Evidence")

    evidence_dir = ROOT / "evidence"

    if evidence_dir.exists():

        images = sorted(
            evidence_dir.glob("*.jpg"),
            key=lambda x: x.stat().st_mtime,
            reverse=True
        )

        if len(images) > 0:

            for row_start in range(
                0,
                min(len(images), 9),
                3
            ):

                cols = st.columns(3)

                for col_idx, image in enumerate(
                images[row_start:row_start + 3]
                ):

                    cols[col_idx].image(
                        str(image),
                        caption=f"""
                        {image.name}

                        Size:
                        {round(image.stat().st_size/1024,2)} KB

                        Modified:
                        {pd.to_datetime(
                        image.stat().st_mtime,
                        unit='s'
                        ).strftime('%Y-%m-%d %H:%M:%S')}
                        """,
                        use_container_width=True
                    )

        else:
            st.warning("No evidence images found.")

    else:
        st.warning("Evidence folder not found.")
    st.subheader("Latest Detections")

    latest_df = df.sort_values(
        by="timestamp",
        ascending=False
    ).head(10)

    st.dataframe(latest_df)

    st.subheader(
    "Detection Records"
    )

    df = df.sort_values(
    by="timestamp",
    ascending=False
    )

    st.dataframe(df)
    csv = df.to_csv(
    index=False
    )

    st.download_button(
        label="Download CSV Report",
        data=csv,
        file_name="road_damage_report.csv",
        mime="text/csv"
    )
    st.markdown("---")

    st.caption(
        "Road Damage Detection System using YOLOv8, SQLite and Streamlit"
    )

except Exception as e:
    st.error(str(e))