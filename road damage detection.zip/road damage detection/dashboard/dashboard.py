import streamlit as st
import pandas as pd
import sqlite3
conn = sqlite3.connect(
    "database_files/pothole.db"
)
df = pd.read_sql(
    "SELECT * FROM detections",
    conn
)
st.title(
    "Road Damage Dashboard"
)
st.dataframe(df)
st.bar_chart(
    df["damage_type"]
        .value_counts()
)