import cv2
from detection.yolo_detector import detect
image = cv2.imread("test.jpg")
detections = detect(image)
print(detections)