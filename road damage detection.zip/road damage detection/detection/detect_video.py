import cv2

from detection.yolo_detector import detect
from database.logger import save_detection
from utils.severity import calculate_severity

cap = cv2.VideoCapture(0)

while True:

    ret, frame = cap.read()

    if not ret:
        break

    detections = detect(frame)

    for d in detections:

        x1, y1, x2, y2 = d["bbox"]

        confidence = d["confidence"]

        damage_type = d["class"]

        if damage_type == "carck":
            damage_type = "crack"

        severity = calculate_severity(
            x1,
            y1,
            x2,
            y2
        )

        save_detection(
            damage_type,
            confidence,
            severity,
            "live_camera"
        )

        cv2.rectangle(
            frame,
            (x1, y1),
            (x2, y2),
            (0, 255, 0),
            2
        )

        label = (
            f"{damage_type} "
            f"{confidence:.2f} "
            f"{severity}"
        )

        cv2.putText(
            frame,
            label,
            (x1, y1 - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (0, 255, 0),
            2
        )

    cv2.imshow(
        "Road Damage Detection",
        frame
    )

    if cv2.waitKey(1) == 27:
        break

cap.release()

cv2.destroyAllWindows()