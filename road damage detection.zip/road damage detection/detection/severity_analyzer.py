def get_severity(area):
    if area < 5000:
        return "Low"
    elif area < 15000:
        return "Medium"
    return "High"