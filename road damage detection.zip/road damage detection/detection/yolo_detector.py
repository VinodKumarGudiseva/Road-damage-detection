from ultralytics import YOLO
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
model = YOLO(str(ROOT / "models" / "best.pt"))
def detect(frame):
    results = model(
    frame,
    imgsz=640,
    verbose=False
)
    detections = []
    for result in results:
        for box in result.boxes:
            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )
            confidence = float(
                box.conf[0]
            )
            class_id = int(
                box.cls[0]
            )
            class_name = model.names[
                class_id
            ]
            detections.append({
                "bbox": [x1, y1, x2, y2],
                "confidence": confidence,
                "class": class_name
            })
    return detections